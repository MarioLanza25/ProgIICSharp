﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ListBoxPractica
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            List<Departamentos> listaDep = new List<Departamentos>();

            listaDep.Add(new Departamentos() { Departamento1 = "Managua", Temperatura1 = 29, Departamento2 = "León", Temperatura2 = 31 });
            listaDep.Add(new Departamentos() { Departamento1 = "Chinandega", Temperatura1 = 31, Departamento2 = "Masaya", Temperatura2 = 28 });
            listaDep.Add(new Departamentos() { Departamento1 = "Matagalpa", Temperatura1 = 26, Departamento2 = "Estelí", Temperatura2 = 26 });
            listaDep.Add(new Departamentos() { Departamento1 = "Jinotega", Temperatura1 = 23, Departamento2 = "Granada", Temperatura2 = 29 });
            listaDep.Add(new Departamentos() { Departamento1 = "Carazo", Temperatura1 = 29, Departamento2 = "Rivas", Temperatura2 = 28 });

            listaDepartamentos.ItemsSource = listaDep;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (listaDepartamentos.SelectedItem != null)
                MessageBox.Show((listaDepartamentos.SelectedItem as Departamentos).Departamento1 + " " +
                    (listaDepartamentos.SelectedItem as Departamentos).Temperatura1 + "°C " +
                    (listaDepartamentos.SelectedItem as Departamentos).Departamento2 + " " +
                    (listaDepartamentos.SelectedItem as Departamentos).Temperatura2 + "°C ");
            else
                MessageBox.Show("Seleccione un elemento");
        }

        private void TextBlock_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (listaDepartamentos.SelectedItem != null)
                MessageBox.Show((listaDepartamentos.SelectedItem as Departamentos).Departamento1 + " " +
                    (listaDepartamentos.SelectedItem as Departamentos).Temperatura1 + "°C " +
                    (listaDepartamentos.SelectedItem as Departamentos).Departamento2 + " " +
                    (listaDepartamentos.SelectedItem as Departamentos).Temperatura2 + "°C ");
            else
                MessageBox.Show("Seleccione un elemento");
        }
    }

    public class Departamentos
    {
        public string Departamento1 { get; set; }
        public int Temperatura1 { get; set; }
        public string Departamento2 { get; set; }
        public int Temperatura2 { get; set; }
        public int DiferenciaTemp { get {
                if(Temperatura2 > Temperatura1)
                    return Temperatura2 - Temperatura1;
                else
                    return Temperatura1 - Temperatura2;
            }
            set { }
        }
    }

}
