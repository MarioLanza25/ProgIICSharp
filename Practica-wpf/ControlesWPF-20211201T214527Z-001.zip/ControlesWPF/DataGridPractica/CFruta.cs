﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGridPractica
{
    class CFruta
    {
        private string nombre;
        private double costo;
        private int cantidad;

        public string Nombre { get => nombre; set => nombre = value; }
        public double Costo { get => costo; set => costo = value; }
        public int Cantidad { get => cantidad; set => cantidad = value; }

        public CFruta(string pNombre, double pCosto, int pCantidad)
        {
            nombre = pNombre;
            costo = pCosto;
            cantidad = pCantidad;
        }

    }
}
