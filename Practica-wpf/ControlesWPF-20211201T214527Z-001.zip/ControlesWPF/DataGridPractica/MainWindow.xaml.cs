﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataGridPractica
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // Creamos una lista para guardar las frutas
            List<CFruta> frutas = new List<CFruta>();

            // Agregamos las frutas
            frutas.Add(new CFruta("Manzana", 12.50, 20));
            frutas.Add(new CFruta("Pera", 7.80, 35));
            frutas.Add(new CFruta("Plátano", 15.30, 10));

            // Colocamos la lista como fuente de elementos para el datagrid
            dgFrutas.ItemsSource = frutas;
        }

        private void BtnSeleccionar_Click(object sender, RoutedEventArgs e)
        {
            CFruta fruta = (CFruta)dgFrutas.SelectedItem;

            string mensaje = string.Format("Fruta:{0}, con costo de ${1}, se tienen {2}",
            fruta.Nombre, fruta.Costo, fruta.Cantidad);
            MessageBox.Show(mensaje, "La fruta seleccionada es");
        }
    }
}
