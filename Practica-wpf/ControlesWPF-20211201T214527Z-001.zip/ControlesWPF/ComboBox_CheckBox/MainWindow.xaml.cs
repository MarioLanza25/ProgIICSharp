﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ComboBox_CheckBox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            List<Municipios> ListaMunicipiosM = new List<Municipios>();

            ListaMunicipiosM.Add(new Municipios { NombreMunicipio = "Managua" });
            ListaMunicipiosM.Add(new Municipios { NombreMunicipio = "Ciudad Sandino" });
            ListaMunicipiosM.Add(new Municipios { NombreMunicipio = "Ticuantepe" });
            ListaMunicipiosM.Add(new Municipios { NombreMunicipio = "Tipitapa" });
            ListaMunicipiosM.Add(new Municipios { NombreMunicipio = "El Crucero" });
            ListaMunicipiosM.Add(new Municipios { NombreMunicipio = "Mateare" });
            ListaMunicipiosM.Add(new Municipios { NombreMunicipio = "San Francisco Libre" });
            ListaMunicipiosM.Add(new Municipios { NombreMunicipio = "San Rafael del Sur" });
            ListaMunicipiosM.Add(new Municipios { NombreMunicipio = "Villa El Carmen" });

            MunicipiosManagua.ItemsSource = ListaMunicipiosM;
        }

        private void TodosM_Checked(object sender, RoutedEventArgs e)
        {
            Managua.IsChecked = true;
            CiudadSandino.IsChecked = true;
            Ticuantepe.IsChecked = true;
            Tipitapa.IsChecked = true;
            ElCrucero.IsChecked = true;
            Mateare.IsChecked = true;
            SanFranciscoLibre.IsChecked = true;
            SanRafaeldelSur.IsChecked = true;
            VillaElCarmen.IsChecked = true;
        }

        private void Individual_Checked(object sender, RoutedEventArgs e)
        {
            if (Managua.IsChecked == true &&
            CiudadSandino.IsChecked == true &&
            Ticuantepe.IsChecked == true &&
            Tipitapa.IsChecked == true &&
            ElCrucero.IsChecked == true &&
            Mateare.IsChecked == true &&
            SanFranciscoLibre.IsChecked == true &&
            SanRafaeldelSur.IsChecked == true &&
            VillaElCarmen.IsChecked == true)
                TodosM.IsChecked = true;
            else
                TodosM.IsChecked = null;
        }

        private void TodosM_Unchecked(object sender, RoutedEventArgs e)
        {
            Managua.IsChecked = false;
            CiudadSandino.IsChecked = false;
            Ticuantepe.IsChecked = false;
            Tipitapa.IsChecked = false;
            ElCrucero.IsChecked = false;
            Mateare.IsChecked = false;
            SanFranciscoLibre.IsChecked = false;
            SanRafaeldelSur.IsChecked = false;
            VillaElCarmen.IsChecked = false;
        }

        private void Individual_Unchecked(object sender, RoutedEventArgs e)
        {
            if (Managua.IsChecked == false &&
            CiudadSandino.IsChecked == false &&
            Ticuantepe.IsChecked == false &&
            Tipitapa.IsChecked == false &&
            ElCrucero.IsChecked == false &&
            Mateare.IsChecked == false &&
            SanFranciscoLibre.IsChecked == false &&
            SanRafaeldelSur.IsChecked == false &&
            VillaElCarmen.IsChecked == false)
                TodosM.IsChecked = false;
            else
                TodosM.IsChecked = null;
        }

    }

    public class Municipios
    {
        public string NombreMunicipio { get; set; }
    }
}
