﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ValidacionesPractica
{
    /// <summary>
    /// Interaction logic for validatingTextBox.xaml
    /// </summary>
    public partial class validatingTextBox : UserControl
    {
        public bool StringValidation { get; set; }
        public validatingTextBox()
        {
            InitializeComponent();
        }

        private void ValidatingTextBox1_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!StringValidation)
                e.Handled = !ValidateText(e.Text);
            else
                e.Handled = !ValidateNum(e.Text);
        }

        private void ValidatingTextBox1_Paste(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(String)))
            {
                String val = (String)e.DataObject.GetData(typeof(String));
                if (!StringValidation)
                {
                    if (!ValidateText(val)) e.CancelCommand();
                }
                else
                {
                    if (!ValidateNum(val)) e.CancelCommand();
                }
            }
            else e.CancelCommand();
        }

            private bool ValidateNum(string text)
        {
            return Array.TrueForAll(text.ToCharArray(),
                delegate (Char c) { return Char.IsLetter(c) || Char.IsControl(c); });
        }

        private bool ValidateText(string text)
        {
            return Array.TrueForAll(text.ToCharArray(),
            delegate (Char c) { return Char.IsDigit(c) || Char.IsControl(c); });
        }
    }
}
