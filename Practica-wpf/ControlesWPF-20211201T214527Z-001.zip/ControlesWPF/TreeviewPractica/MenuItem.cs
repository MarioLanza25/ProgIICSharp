﻿using System;
using System.Collections.Generic;

// Namespace necesario
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeviewPractica
{
    class MenuItem
    {
        // Aquí colocamos los elementos que guarda
        /*
         * ObservableCollection es una colección que permite que el código fuera
         * de la colección sea consciente de cuándo se producen cambios 
         * en la colección (agregar, mover, eliminar).
         */
        public ObservableCollection<MenuItem> Elementos { get; set; }
        public string Nombre { get => nombre; set => nombre = value; }

        private string nombre;

        public MenuItem(string pNombre)
        {
            // Instanciamos la colección
            Elementos = new ObservableCollection<MenuItem>();
            nombre = pNombre;
        }
    }
}
